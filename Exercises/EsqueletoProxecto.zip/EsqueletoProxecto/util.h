#ifndef UTIL_H_INCLUDED
#define UTIL_H_INCLUDED

/*
        Le cadeas e numeros por teclado
*/

    # define MAXCAD 200 //Dimension maxima das cadeas de caracteres

    void lerCadea(char mensaxe[ ], char cad []);
    int lerEnteiro(char mensaxe []);

#endif // UTIL_H_INCLUDED
